package com.katari.amq.listener;


import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class MyListener {

	@JmsListener(destination = "${destination.topic}",
			subscription = "${destination.topic}",
			//this was also needed with the same name as the bean above
			containerFactory = "jmsListenerContainerFactory" 
			)
	public void reciver(String msg) {
		System.out.println(msg);
	}
}
