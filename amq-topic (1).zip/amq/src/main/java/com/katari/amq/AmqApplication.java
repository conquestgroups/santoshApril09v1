package com.katari.amq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmqApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmqApplication.class, args);
	}

}
